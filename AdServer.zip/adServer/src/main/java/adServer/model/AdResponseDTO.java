package adServer.model;

public class AdResponseDTO {
	
	 private String statusDesc;
	 private Integer statuscode;
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public Integer getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(Integer statuscode) {
		this.statuscode = statuscode;
	}

	 
	 
	 
}
